export const environment = {
  production: true,
  API_URL: 'https://damp-spire-59848.herokuapp.com',
};
