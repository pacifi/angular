export interface Auth {
  access_token: string;
}
