export interface FileRta {
  originalname: string;
  filename: string;
  location: string;
}
